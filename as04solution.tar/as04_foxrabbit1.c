/*******************************************************************************
  PHYS3071 (and PHYS7073) Assignment 4 Baumgardt 0123456
 
  Program as04_foxrabbits (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This C program calculates population changes in two species
         based on the Lotka-Volterra equations and using Euler's mechanism
 
  Compile: gcc -Wall as04_foxrabbits.c -o as04_foxrabbits
 
  Input: The initial number of species x_0, y_0, the end time t_fin and
         the timesteps dt and dtout
 
  Output: x(t) and y(t) at final time 
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>


// These are the constants controlling the interaction of the species
#define ALPHA  1.5
#define BETA   0.1
#define GAMMA  3.0
#define DELTA  0.1

int main() {
 double x,y;        // Number of animals
 double dt,dtout;   // Time steps
 double tfin,tout=0.0,t=0.0;  // Final time, output time and actual time
 FILE *outfile;

 printf("Input the initial number of prey animals: ");
 scanf("%lf",&x);

 printf("Input the initial number of predator animals: ");
 scanf("%lf",&y);

 printf("Input the time step: ");
 scanf("%lf",&dt);

 printf("Input the end time: ");
 scanf("%lf",&tfin);

 printf("Input the output frequency: ");                           
 scanf("%lf",&dtout);

 if (tfin<0 || dt<0.0 || dtout<0.0 || x<0.0 || y<0.0) {
    printf("Illegal input, all values must be larger than zero !\n");
    exit(-1);
 }

// Open output file 
 outfile=fopen("example1.dat","w");

 do {
   if (t>=tout) {
     fprintf(outfile,"%10.6lf %10.4lf %10.4lf\n",t,x,y);
     tout += dtout;
   }

   x += dt*(x*ALPHA-BETA*x*y);    // Change in x per step
   y += dt*(-y*GAMMA+DELTA*x*y);  // Change in y per step
   t  += dt;
 } while (t<=tfin);

 fclose(outfile);

 printf("\nThe final number of animals are:  Prey: %lf  Predator:  %lf\n",x,y);

 printf("\nProgram finished OK\n\n"); 
 exit(0);
}

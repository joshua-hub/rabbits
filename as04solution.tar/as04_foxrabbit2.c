/***********************80*character*limit*good*for* a2ps*********************** 
  Program as04_foxrabbits (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This C program calculates population changes in two species
         based on the Lotka-Volterra equations and using Euler's mechanism
         and determines the stable point through iteration
 
  Compile: gcc -Wall as04_foxrabbit2.c -o as04_foxrabbit2
 
  Input: The initial number of species x_0, y_0, the end time t_fin and
         the timestep dt
 
  Output: x(t) and y(t) 
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define ALPHA  1.5
#define BETA   0.1
#define GAMMA  3.0
#define DELTA  0.1

int main() {
 double x,y,dt,tfin,t;
 double dx,dy;
 double xmin,xmax,ymin,ymax;
 int iter=0;

 printf("Input the initial number of prey animals: ");
 scanf("%lf",&x);

 printf("Input the initial number of predator animals: ");
 scanf("%lf",&y);

 printf("Input the time step: ");
 scanf("%lf",&dt);

 printf("Input the end time: ");
 scanf("%lf",&tfin);

 if (tfin<0 || dt<0.0 || x<0.0 || y<0.0) {
    printf("Illegal input, all values must be larger than zero !\n");
    exit(-1);
 }

 printf("\n");

 do {
   iter++;

   t = 0.0;

   xmin = 1E10;
   xmax = -1.0;
   ymin = 1E10;
   ymax = -1.0;
 
   do {
       dx = dt*(x*ALPHA-BETA*x*y);
       dy = dt*(-y*GAMMA+DELTA*x*y);
       t  += dt;

       x += dx;
       y += dy; 
  
       if (x<xmin) xmin=x;
       if (x>xmax) xmax=x;
       if (y<ymin) ymin=y;
       if (y>ymax) ymax=y;
    } while (t<tfin);

   printf ("Iteration: %i  xmin: %lf  xmax: %lf  ymin: %lf ymax: %lf\n",iter,xmin,xmax,ymin,ymax);

   x = (xmin+xmax)/2.0;
   y = (ymin+ymax)/2.0;

   if (iter>30) {
     printf("No convergence !\n");
     exit(-1);
   }
 } while (fabs(xmin-xmax)>0.001 && fabs(ymin-ymax)>0.001);

 printf("\nStable point found at x=%lf  y=%lf\n",x,y);
 exit(0);
}
